#pragma once
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class punkt{
protected:
	double x, y;
	string id;
public:
	punkt() {
		x = 0;
		y = 0;
		id = "default";
		cout << "konstruktor domyslny (punkt) " <<id<< endl;
	}
	punkt(string str, double a, double b) {
		x = a;
		y = b;
		id = str;
		cout << "konstruktor parametryczny (punkt) " <<id<< endl;
	}
};

class kolo : protected punkt {
protected:
	double r;
public:
	kolo() {
		r = 1;
		cout << "konstruktor domyslny (kolo) " <<id<< endl;
	}
	kolo(string str, double a, double b, double c):punkt(str, a, b) {
		r = c;
		cout << "konstruktor parametryczny (kolo) " <<id<< endl;
	}
};

class walec : protected kolo {
protected:
	double h;
public:
	walec() {
		h = 1;
		cout << "konstruktor domyslny (walec) " <<id<< endl;
	}
	walec(string str, double a, double b, double c, double d) :kolo(str, a, b,c) {
		h = d;
		cout << "konstruktor parametryczny (walec) " <<id<< endl;
	}
};

class kwadrat : protected punkt {
protected:
	double l;
public:
	kwadrat() {
		l = 1;
		cout << "konstruktor domyslny (kwadrat) " <<id<< endl;
	}
	kwadrat(string str, double a, double b, double c) :punkt(str, a, b) {
		l = c;
		cout << "konstruktor parametryczny (kwadrat)" <<id<< endl;
	}
};

class prostopadloscian : protected kwadrat {
protected:
	double h;
public:
	prostopadloscian() {
		h = 1;
		cout << "konstruktor domyslny (prostopadloscian) " <<id<< endl;
	}
	prostopadloscian(string str, double a, double b, double c, double d) :kwadrat(str, a, b, c) {
		h = d;
		cout << "konstruktor parametryczny (prostopadloscian) " <<id<< endl;
	}
};