#include "class.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {

	walec w1;
	cout << endl;
	walec w2("parametr1",1,2,3,4);
	cout.width(40);
	cout.fill('-');
	cout<<""<< endl;
	prostopadloscian p1;
	cout << endl;
	prostopadloscian p2("parametr2", 1, 2, 3, 4);
	getchar();
	cin.ignore();
	return 0;
}