#pragma once
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;



class figura {
public:
	virtual void pole() = 0;
	~figura(){
		cout << "usuwanie figury" << endl; 
	}

};

void pole(figura* wsk) {
	wsk->pole();
}

class kwadrat:public figura{
protected:
	double a;
public:
	kwadrat(double x) {
		a = x;
	}
	virtual void pole() {
		cout << "Pole kwadratu wynosi: " << a * a << endl;
	}
	~kwadrat() {
		cout << "usuwanie kwadratu" << endl;
	}

};

class prostopadloscian :public kwadrat {
protected:
	double h;
public:
	prostopadloscian(double x, double y):kwadrat(x) {
		h = y;
	}
	virtual void pole() {
		cout << "Pole prostopadloscianu wynosi: " << (4 * a * h + 2* a*a) << endl;
	}
	virtual ~prostopadloscian() {
		cout << "usuwanie prostopadloscianu" << endl;
	};
};

class kolo :public figura {
protected:
	double r;
public:
	kolo(double x) {
		r = x;
	}
	virtual void pole() {
		cout << "Pole kola wynosi: " <<  3.14 * r *r << endl;
	}
	~kolo() {
		cout << "usuwanie kola" << endl;
	};
};

class walec :public kolo {
protected:
	double h;
public:
	walec(double x, double y) :kolo(x) {
		h = y;
	}
	virtual void pole() {
		cout << "Pole walca wynosi: " << 2 * 3.14 * r * h + 2*r*r*3.14 << endl;
	}
	~walec() {
		cout << "usuwanie walca" << endl;
	};

};
