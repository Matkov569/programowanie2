#include "klasy.h"

int main() {
	figura* wsk;
	kwadrat k1(3);
	prostopadloscian p1(4, 5);
	kolo c1(2);
	walec w1(3, 4);
	
	wsk = &k1;
	wsk->pole();
	pole(wsk);

	wsk = &p1;
	wsk->pole();
	pole(wsk);

	wsk = &c1;
	wsk->pole();
	pole(wsk);

	wsk = &w1;
	wsk->pole();
	pole(wsk);

	cout.width(40);
	cout.fill('=');
	cout << "" << endl;
	

	getchar();
	cin.ignore();
	return 0;
}