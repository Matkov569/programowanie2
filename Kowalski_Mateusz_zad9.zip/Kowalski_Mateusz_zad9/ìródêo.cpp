#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

double dzielenie(double a, double b) {
	if (b == 0) {
		string wyjatek = "dzielnik nie moze byc zerem!";
		throw wyjatek;
	}
	return a / b;
}

int modulo(int a, int b) {
	if (a == b) {
		string wyjatek= "dzielna i dzielnik sa jednakowe!";
		throw wyjatek;
	}
	else if (a%b==0) {
		string wyjatek="dzielna nie moze byc wielokrotnoscia dzielnika!";
		throw wyjatek;
	}
	return a % b;
}

int main() {
	int a, b;
	double c, d;
	cout << "Podaj liczby do dzielenia a/b: ";
	cin >> c;
	cin >> d;
	cout << endl << "Podaj liczbe do dzielenia modulo a%b: ";
	cin >> a;
	cin >> b;
	bool dziel=1, mod=1;

	try {
		dzielenie(c, d);
	}
	catch(string wyjatek){
		cout << endl << "Wyjatek: " << wyjatek;
		dziel = 0;
	}
	if (dziel) cout << endl <<c<<"/"<<d<<"="<< dzielenie(c, d);

	try {
		modulo(a, b);
	}
	catch (string wyjatek) {
		cout << endl << "Wyjatek: " << wyjatek;
		mod = 0;
	}
	if (mod) cout << endl << a << "%" << b << "=" << modulo(a, b);

	cin.ignore();
	getchar();
	return 0;
}