#include <iostream>
#include <string>
#include "funkcje.h"
using namespace std;

void body::fillin() {
	vc = 1;
	ve = 2;
	vd = 3;

	wc = 4;
	we = 5;
	wd = 6;
	cout << "Fillin dla body skonczony";
}

void nav::fillin() {
	vc = 1;
	ve = 2;
	vd = 3;

	wc = 4;
	we = 5;
	wd = 6;

	fc = 7;
	fe = 8;
	fd = 9;
	cout << "Fillin dla nav skonczony";
}