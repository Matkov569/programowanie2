#pragma once

#include <iostream>
#include <string>
using namespace std;

class html;
class body;
class nav;



class html {
	public:
		int vc;
	private:
		int ve;
	protected:
		int vd;
};

class body : public html {
	public:
		int wc;
		void fillin();
	private:
		int we;
	protected:
		int wd ;
};

class nav : public body {
	public: 
		int fc;
		void fillin();
	private:
		int fe;
	protected:
		int fd;
};