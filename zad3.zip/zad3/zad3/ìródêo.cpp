#include <iostream>
#include <string>
#include "funkcje.h"
using namespace std;

int main() {

	html H;
	body B;
	nav N;
	int p;
	B.fillin();
	N.fillin();

	p = H.vc;
	p = H.ve;
	p = H.vd;

	/////

	p = B.vc;
	p = B.ve;
	p = B.vd;

	p = B.wc;
	p = B.we;
	p = B.wd;

	/////

	p = N.vc;
	p = N.ve;
	p = N.vd;

	p = N.wc;
	p = N.we;
	p = N.wd;

	p = N.fc;
	p = N.fe;
	p = N.fd;

	getchar();
	cin.ignore;
	return 0;
}